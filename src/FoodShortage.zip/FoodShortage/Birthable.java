package FoodShortage;

public interface Birthable {
    String getBirthDate();
}
