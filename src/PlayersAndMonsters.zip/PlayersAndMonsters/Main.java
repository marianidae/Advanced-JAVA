package PlayersAndMonsters;

public class Main {
    public static void main(String[] args) {
        DarkKnight darkKnight = new DarkKnight("Pesho", 13);
        System.out.println(darkKnight);
    }
}
