package OOP.WorkingWithAbstraction.greedyTimes;

public enum ItemType {
    GOLD,
    CASH,
    GEM
}
