package Тelephony;

public interface Browsable {
    String browse();
}
